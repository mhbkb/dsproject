# dsproject
Upload the *.zip file to 
https://us-west-2.console.aws.amazon.com/elasticbeanstalk/home?region=us-west-2#/environment/dashboard?applicationName=dsp2&environmentId=e-gu32r8kxmi
It will auto deploy to aws.

Application can be accessed by  http://flask3.qst6ftqmmz.us-west-2.elasticbeanstalk.com/
